package com.codewithayas.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Setter
@Getter
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class Image {
	private static final int maxContentSize = 0;
	 
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Long id;
	 
	private  String postname;
	@Lob
	@Column(length=maxContentSize)
	private byte[]postimage;


}
