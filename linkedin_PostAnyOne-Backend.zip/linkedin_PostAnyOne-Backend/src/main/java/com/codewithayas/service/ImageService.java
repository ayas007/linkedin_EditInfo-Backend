package com.codewithayas.service;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.codewithayas.entity.Image;
import com.codewithayas.repository.ImageRepository;

@Service
public class ImageService {
	
	@Autowired
	private ImageRepository imageRepository;
	
	 

	public String saveImage(MultipartFile file, String postname) throws IOException {
		 Image image=new Image();
		 image.setPostname(postname);
		 image.setPostimage(file.getBytes());
		 imageRepository.save(image);
		return  "image save in DB";
	}

 

}
